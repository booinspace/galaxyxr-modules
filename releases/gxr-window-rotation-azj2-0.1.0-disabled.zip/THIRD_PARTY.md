# Sources and credits

- [BlueScorpioVR/galaxyxr-modules](https://github.com/BlueScorpioVR/galaxyxr-modules)
  demonstrated supervised SystemUI injection and adding controls to the
  Galaxy XR caption menu. Its window-curvature module informed the lifecycle
  design. This rotation helper and its agent are newly written; the curvature
  agent and native mesh patches are not bundled.
- [Frida 17.23.3](https://github.com/frida/frida/releases/tag/17.23.3) supplies
  the unmodified Android arm64 injector. SHA-256 of its decompressed ELF:
  `bc4e1a0c7ede20af387e9e002a535cb3ff0072f523c460692820473b3f07e122`.
  The package includes the upstream COPYING notice and LGPL 2.0 or later text.
- [frida-java-bridge 7.0.13](https://www.npmjs.com/package/frida-java-bridge/v/7.0.13)
  is bundled into the agent; its original npm archive is included as well.
  It comes from the verified borderless runtime ZIP pinned in the builder.
- [Eclipse JDT ECJ 3.39.0](https://repo.maven.apache.org/maven2/org/eclipse/jdt/ecj/3.39.0/)
  and [Android D8/R8](https://developer.android.com/tools/d8) compile the Java
  helper. They are host build tools and are not installed on the headset.
- Compatibility analysis used the stock AZJ2 SystemUI APK and framework JAR
  read from the user's SM-I610. Those proprietary binaries are not included.

This work targets `UML2.260301.001.I610UES3AZJ2`. The build receipt records
source and tool hashes. An experimental build is not a security audit of its
runtime dependencies.
