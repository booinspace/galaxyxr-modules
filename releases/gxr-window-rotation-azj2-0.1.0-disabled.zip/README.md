# Window rotation for Galaxy XR AZJ2

This experimental KernelSU GXR module adds **Pitch**, **Yaw**, **Roll**, and
**Reset rotation** to an ordinary app window's top menu. Pinch and drag a
slider, then release it to apply the angle. The stock caption drag still moves
the window through space. This version uses three sliders for rotation; it
does not add a direct hand grab gesture for free rotation.

**Status: built for AZJ2; device behavior still needs validation.** The first
test must run with both borderless and curvature disabled. Those modules use
separate injectors, and their combined operation has not been established.
This module refuses to start while either is enabled or another injector is
running.

## Install and first test

1. Leave DirtyFrag Autorun off. Disable borderless and curvature, fully reboot
   the headset, and regain temporary root. This removes old process hooks
   before the first rotation test.
2. Copy `releases/gxr-window-rotation-azj2-0.1.0-disabled.zip` to
   `/sdcard/Download/`. In KernelSU GXR use **Modules → Install from storage**.
   The ZIP installs disabled.
3. Enable **Galaxy XR window rotation (AZJ2)**, then tap its **Action**. It
   starts the runtime and shows its status. A Soft restart is not needed.
   KernelSU's own window is excluded from rotation so it remains available
   for recovery.
4. Open an ordinary app window. Point at its top caption and open the app's
   contextual menu. Pitch, Yaw and Roll sliders should appear below the stock
   controls. Start with about 10° of pitch or yaw, release, and check that the
   picture, caption, menu and app input all follow the same plane. Test stock
   dragging. Then test 90° or -90° roll for lying on either side.
5. **Reset rotation** returns that window to its stock local orientation.
   Opening its menu again should retain the angles for that live window.
   Closing the window or restarting SystemUI discards its state.

Positive and negative labels refer to local axes, relative to the stock window
pose. Pitch and yaw can turn a panel edge-on or away from you. If its controls
become unreachable, turn rotation off in KernelSU to restore the window.

## Stop, logs and recovery

Turn the module's checkbox off and wait up to 18 seconds. The supervisor asks
the Java helper to restore each live window's local orientation and remove
its controls, then detaches the injector. Open menus may close during cleanup.
KernelSU GXR's uninstall path checks `GXR_UPDATE_STATE=STOCK` before removal.

While running, **Action** reports status and exports available diagnostics to
ADB shell, without reattaching:

```sh
adb pull /data/local/tmp/gxr-rotation-runtime.log
adb pull /data/local/tmp/gxr-rotation-failure
adb logcat -d -s GXRRotation:I
```

An absent failure file is normal. If the runtime fails, it disables its
checkbox. You may enable it solely to use Action for log export; an existing
failure marker prevents another attach. Turn it off again afterward. A full
reboot clears live rotation; with Autorun off, regain root manually if needed.
The next Action after a full reboot archives the old failure and session log
automatically. No separate diagnostic or reset module is required.

Use one attach per SystemUI process. After a stopped test, fully reboot before
another test. Avoid a Soft restart while the module is attached. Module files
can survive reboot even though the DirtyFrag root session is temporary.

## How it works and limits

The exact AZJ2 framework exposes
`CPM.NodeUpdates.setOrientation(node, w, x, y, z)`. The module applies a unit
quaternion to the task's window node, using yaw(Y) × pitch(X) × roll(Z).
AZJ2's caption decoration is parented to that node, and its contextual menu is
parented to the decoration. This is the basis for keeping the visual panel
and its input surfaces aligned; that alignment must be checked on the headset.
Stock position, scale and caption drag handlers are used as supplied by
SystemUI.

The helper hooks `XrCaptionMenu.bindMenu` and adds Java-owned controls after
the stock menu is bound. Java performs both the angle change and cleanup.
An independent Java heartbeat check restores orientation if the injector
disappears. The shell supervisor also watches SystemUI's process identity and
refuses automatic reattachment after an interruption.

The runtime checks SM-I610, fingerprint
`samsung/xrvst2ue/xrvst2:14/UML2.260301.001/I610UES3AZJ2:user/release-keys`,
and exact SystemUI APK, framework JAR and SpaceFlinger library hashes in
`firmware.sha256`. It does not replace firmware files. Other firmware,
immersive apps, multiple pose modifiers, and combined operation with the other
window modules are outside this first build's validation.

## Build

From the repository root, use Python with `frida==17.23.3`, Java, ECJ 3.39.0,
the Android SDK's R8 JAR, and an Android platform JAR. The build takes its
unmodified Frida runtime and Java bridge from the checked-in borderless 0.2.0
ZIP after verifying that ZIP's pinned SHA-256. Borderless does not have to be
installed on the headset.

```sh
python scripts/build-window-rotation.py \
  --java /usr/bin/java \
  --ecj /home/nathalie/galaxy-xr-azj2/curvature-deps/ecj-3.39.0.jar \
  --r8 /home/nathalie/galaxy-xr-azj2/android-sdk/cmdline-tools/latest/lib/r8.jar \
  --android-jar /home/nathalie/galaxy-xr-azj2/android-sdk/platforms/android-37.0/android.jar
python tests/window-rotation-control.test.py
shellcheck modules/window-rotation/*.sh
```

The build runs the Java quaternion tests, compiles the helper DEX and Frida
agent, and validates the disabled ZIP, its checksums and complete payload. The
ZIP includes the helper/agent/build sources, dependency hashes, DEX hash, and
runtime notices. These host checks do not establish XR input or display
behavior. See [THIRD_PARTY.md](THIRD_PARTY.md) for credits and pinned runtime
sources.
