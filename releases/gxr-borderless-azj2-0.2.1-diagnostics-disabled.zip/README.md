# Borderless Home Space app windows for Galaxy XR AZJ2

This KernelSU GXR module hides the thin white rim around ordinary floating
Android app windows. Version 0.2.0 also hides the resting caption pill and
reveals it while pointing at the top caption area. The caption's parent view,
window size, input surface and drag handler remain in place. Close and reopen
an existing app window after enabling the module to apply both changes.

**Status: 0.2.0 rim and resting pill removal worked on the headset.** A later
startup reached `GXR_BORDERLESS_READY`, suppressed the first rim, then failed
with `TypeError: not a function`. Version 0.2.1 keeps the same hooks and adds
callback names and JavaScript stacks to failure logs; it has not been tested
on the headset. The exact AZJ2
SystemUI code shows `SpaceFlingerCpmSubgraph` setting the main window's rim
through `CPM.NodeUpdates.enablePanelBorderRim`. Input, reform and window
dragging use separate code paths. The module calls `disablePanelBorderRim`
for new `task-<id>` windows and keeps later rim updates disabled for those
windows. It makes `caption_background` invisible without removing the parent
caption view or its touch listener. Hover over that parent makes the pill
visible; it hides half a second after hover leaves, allowing a click to finish.
The pill is restored when the hook stops.

The first 0.1.0 ZIP failed GXR installation because it omitted the required
`auto.sh` file. Version 0.1.1 fixed installation and its border removal was
confirmed on this headset.

## Compatibility

- Samsung Galaxy XR SM-I610, Android 14, build
  `UML2.260301.001.I610UES3AZJ2` only.
- Exact `/system_ext/priv-app/XrSystemUI/XrSystemUI.apk` SHA-256:
  `dc664a17617b97d2aafebac9690c4235f530cd24399fbe16b6634d5df2a6a6dc`.
- Active KernelSU GXR root and its module service dispatch are required. This
  module does not obtain root and is not an APK.
- AZF3 and other firmware revisions are outside this build. The runtime
  refuses a firmware mismatch before attaching to SystemUI.
- The hook matches `task-<id>` subgraphs. Immersive XR tasks may share that
  naming; their main rim may also be suppressed. Immersive and system-owned
  window behavior has not been tested.

## Install and test

1. Confirm KernelSU GXR says **Working [Jailbreak mode]**. Leave DirtyFrag
   **Autorun off**.
2. From this repository's root, copy the release ZIP to the headset:

   ```sh
   adb push releases/gxr-borderless-azj2-0.2.1-diagnostics-disabled.zip /sdcard/Download/
   ```

3. In **KernelSU GXR → Modules**, choose **Install from storage** and select
   the ZIP. It installs **disabled**. Do not select **Use local LKM file**;
   that is the separate kernel installation path.
4. In GXR **Settings**, turn on **Soft restart instead of reboot**. Enable the
   borderless module's checkbox, then use **Soft restart** from the Modules
   screen so module services run. A full reboot loses the current DirtyFrag
   root session.
5. Open a new ordinary app window, or close and reopen an existing one. Confirm
   that the perimeter and resting pill disappear. Point at the top caption area
   to reveal the pill. Try dragging, resizing, closing, and opening its menu.
   The app's own black bars are outside this change.
6. The module's **Action** button reports whether the hook attached and whether
   an app caption reached it. `GXR_BORDERLESS_SUPPRESSED` in `runtime.log`
   confirms the rim code path ran; `GXR_BORDERLESS_CAPTION_HIDDEN` confirms a
   caption was hidden. A visual and drag check still matters.

## Disable and recover

Turn the module checkbox off. The supervisor asks the injector to detach and
stops within about 12 seconds. The pill becomes visible again; reopen affected
windows to restore their stock rim. The module never restarts SystemUI itself.
If SystemUI becomes unstable, disable the module and restart the headset; the hook is only in process memory.
After a full reboot, obtain root again only if you need GXR services.

To update a running 0.1.1 installation, turn its checkbox off and perform a
full headset reboot with DirtyFrag Autorun off. Reacquire temporary root and
install the later ZIP while disabled. The 0.1.1 injector cannot attest that every
existing rim returned to stock in the same boot, which the GXR updater
requires. Rebooting resets the SystemUI process and its rims.

To diagnose a failed 0.2.0 startup, disable Borderless and Curvature, fully
reboot, and regain temporary root. Install 0.2.1 from storage; it replaces
0.2.0 and installs disabled. Enable **Borderless only** and use one GXR Soft
restart. Its Action shows the callback name, while Recovery 0.1.1's Action
exports the full Borderless `runtime.log` to `/data/local/tmp/` for ADB. Leave
Curvature disabled until Borderless runs without a fatal log entry.

The Action status and diagnostic files are under
`/data/adb/modules/gxr_borderless_azj2/`. A failed attach disables the module
and writes `failure` and `runtime.log`. Do not immediately re-enable after a
failure in the same SystemUI process. Reboot with the module disabled, inspect
the log, and report the result before retrying. Uninstall from GXR Modules once
the hook has stopped. KernelSU module files can survive reboot even when the
temporary root does not.

## Build and source

The source is `agent.js` and the shell scripts in this directory. Run
`scripts/build-borderless.py` as described in
[`../../docs/BORDERLESS.md`](../../docs/BORDERLESS.md). The build verifies the
pinned Frida injector and Java bridge hashes, bundles the agent, and produces a
disabled, checksummed ZIP. No system APK or native library is replaced.

The [BlueScorpioVR window-curvature module](https://github.com/BlueScorpioVR/galaxyxr-modules/tree/main/modules/window-curvature)
provided the supervised Frida injection pattern. It targets AZF3 and changes
window curvature; this module uses a separate AZJ2 main-window rim API and does
not include its mesh patch. See `THIRD_PARTY.md` for runtime components.
