#!/system/bin/sh
[ "$BOOTMODE" = true ] || abort 'Install from the running KernelSU Manager, not recovery.'
[ "$ARCH" = arm64 ] || abort 'Android arm64 is required.'
[ "$(getprop ro.product.model)" = SM-I610 ] || abort 'This build is for Galaxy XR SM-I610 only.'
ui_print 'Experimental Home Space curvature; installing DISABLED.'
ui_print 'Enable in KernelSU and reboot when ready. No interface restart is performed.'
previous_features=/data/adb/modules/gxr_window_curvature/features.conf
if [ -f "$previous_features" ] && [ "$MODPATH" != /data/adb/modules/gxr_window_curvature ]; then
  cp "$previous_features" "$MODPATH/features.conf" || abort "Cannot retain feature settings"
fi
sh "$MODPATH/features.sh" wire >/dev/null || abort "Invalid saved feature settings"
set_perm_recursive "$MODPATH" 0 0 0755 0644
set_perm "$MODPATH/bin/frida-inject" 0 0 0755
for script in service.sh action.sh auto.sh control.sh uninstall.sh features.sh pins.sh recovery.sh boot-recovery.sh restart.sh restart-prepare.sh restart-stopped.sh restart-started.sh restart-abort.sh; do
  set_perm "$MODPATH/$script" 0 0 0755
done
: > "$MODPATH/disable"
: > "$MODPATH/skip_mount"

[ ! -f "$MODPATH/features.conf" ] || set_perm "$MODPATH/features.conf" 0 0 0600

previous_pin=/data/adb/modules/gxr_window_curvature/pin-app.conf
if [ -f "$previous_pin" ] && [ "$MODPATH" != /data/adb/modules/gxr_window_curvature ]; then
  cp "$previous_pin" "$MODPATH/pin-app.conf" || abort "Cannot retain pinned app selection"
  set_perm "$MODPATH/pin-app.conf" 0 0 0600
fi
