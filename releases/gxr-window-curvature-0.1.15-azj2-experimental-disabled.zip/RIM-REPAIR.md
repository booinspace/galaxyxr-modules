# Curved mesh repair candidate

The initial three-minute device test passed: rounded background/header corners
were visible in screenshots, the owner reported head-motion rim flicker gone,
SystemUI identity stayed unchanged, and live stop restored all windows flat with
no FATAL/CLEANUP_PENDING events. One curved task exercised two paired repairs.
Additional multi-window/lifecycle and controlled performance coverage is pending.

October 25 follow-up: the owner approved local installation of versionCode 103,
SHA256 7a3af15594badeaf95f67ae632fff1a2dd3dd858500b98700b6df16d95c76fde.
The original module was backed up before reviewed installation. Following a
KernelSU soft restart, SystemUI PID 3573 remained unchanged throughout testing.
Two windows at 50% curvature were held constant for fixed/original/fixed phases:
GPU busy means were 58.71%, 80.14%, and 64.00%, respectively (seven samples each).
Fixed phases stayed at 421MHz; original draws used 421/456/492MHz. AP read 73.1C
and thermal status stayed SEVERE. These short sampled results support reduced GPU
overhead, not a battery-life or frame-time guarantee. CPU did not clearly improve.
The owner reported resize, typing, flatten/recurve, and close/reopen all passed,
with rounded corners and stable rim preserved. No FATAL/CLEANUP_PENDING was logged.
The installed fix remains enabled; no public release/feed was changed. Cold boot,
uninstall/update recovery, broad immersive/dialog coverage and soak remain open.

The pinned renderer replaces the flat split interior/edge meshes with full curved
quads for both members of each primitive pair. The interior variant does not run
the shader's rounded-corner/edge masking; it can therefore cover the properly
rounded edge variant with square opaque content. Rendering both full quads also
adds redundant GPU work. Actual motion-dependent flicker causation remains a
device-test question, not a claim established by disassembly alone.

The candidate keeps primitives 1 and 3, including their original radius inputs,
root bounds/offsets, textures, rim colors and rim width. It reduces the index counts
of the matched unmasked primitives 0 and 2 to zero and submits that geometry through
the firmware's MeshRenderer::SetRenderableGeometry API. Mesh ownership, vertex
and index buffers and materials remain with the engine. This is not a global
shader patch, a depth-order override, or a hidden-rim workaround.

## Scope and guards

- Existing APK, renderer and Impress SHA256 gates remain mandatory.
- Additional GetMesh/SetRenderableGeometry symbol offsets must match this firmware.
- Run only at the existing exact direct-visibility override callsite, inside a
  tracked eligible task/caption frame with an unexpired supervisor lease.
- Native surface curvature must be finite, positive and within the supported range.
- Validate four independent matched full-quad primitives, triangle counts and
  matching cached geometry counts before either pair is changed.
- Do not retain native mesh pointers across calls. Regenerated meshes after resize
  are checked/repaired again; ordinary flat meshes are never edited by this path.
- A repeated call for already suppressed primitives submits no geometry again.
- A native API exception restores attempted index counts, cached ranges and GPU
  geometry before propagating the failure into the existing stop/flatten path.

## Restoration contract

Changing curvature back to zero follows the engine's original UpdateMesh path,
which constructs fresh flat split meshes. The candidate keeps all renderer hooks
until the existing Java stop/flatten protocol completes, just as before. No raw
pointer restoration registry is used. Human testing must explicitly cover resize,
curve/flatten/recurve, close/reopen and supervised live stop before installation is
considered validated. Full process death still relies on the Java lease watchdog.

## Bounded same-session performance diagnostic

Root may send `mesh-baseline N` (N=1..60 seconds) through the existing injector
stdin FIFO for a controlled comparison. Only the owned eligible curved surfaces
are affected. It restores the original full interior draws using the verified
matched edge counts, so the old clipping defect may intentionally reappear.
The default repair resumes automatically on render callbacks after the monotonic
deadline, even if no further diagnostic command arrives. `mesh-fixed` ends the
comparison early. Neither command changes curvature, watchdog leases, settings,
checkboxes or shader materials. No pointer registry or network endpoint is added.

## Validation still required

Host policy/transaction tests alone do not prove visible correctness. The initial
device result above establishes a bounded visual/runtime pass, not broad lifecycle
certification. The bounded comparison command also needs device verification.
Compare GPU load using
the same windows, curvature, boot and similar thermal conditions; eliminating two
redundant primitive draws is not a promise to eliminate all curved-rendering cost.

Build with --no-update-feed while this is a local candidate. Do not publish or
replace the installed working module merely because host tests pass.
