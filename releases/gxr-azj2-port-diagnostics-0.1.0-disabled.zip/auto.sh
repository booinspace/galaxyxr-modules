#!/system/bin/sh
echo GXR_UPDATE_STATE=STOCK
